package lthsk_QLSach_stt08_HuynhThanhCuong_24639461;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Calendar;

public class QuanLySachApp extends JFrame implements ActionListener {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private JTextField txtMaSach, txtTuaSach, txtTacGia, txtNamXB, txtNhaXB, txtSoTrang, txtDonGia, txtISBN, txtMess;
    private JButton btnThem, btnXoaRong, btnSua, btnXoa, btnLuu, btnLoc;
    private JComboBox<String> cboMaSach;
    private JTable table;

    private SachTableModel tableModel;
    private DanhSachSach thuvien;

    public QuanLySachApp() {
        setTitle("Quản lý sách - IO Character Streams");
        setSize(950, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(5, 5));

        JPanel pnlNorth = new JPanel();
        pnlNorth.setLayout(new BoxLayout(pnlNorth, BoxLayout.Y_AXIS));
        pnlNorth.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Records Editor", TitledBorder.LEFT, TitledBorder.TOP));

        txtMaSach = new JTextField();
        txtTuaSach = new JTextField();
        txtTacGia = new JTextField();
        txtNamXB = new JTextField();
        txtNhaXB = new JTextField();
        txtSoTrang = new JTextField();
        txtDonGia = new JTextField();
        txtISBN = new JTextField();

        pnlNorth.add(taoDong("Mã sách:", txtMaSach, null, null));
        pnlNorth.add(taoDong("Tựa sách:", txtTuaSach, "Tác giả:", txtTacGia));
        pnlNorth.add(taoDong("Năm xuất bản:", txtNamXB, "Nhà xuất bản:", txtNhaXB));
        pnlNorth.add(taoDong("Số trang:", txtSoTrang, "Đơn giá:", txtDonGia));
        pnlNorth.add(taoDong("International Standard Book Number (ISBN):", txtISBN, null, null));

        JPanel pnlMess = new JPanel(new FlowLayout(FlowLayout.LEFT));
        txtMess = new JTextField(60);
        txtMess.setEditable(false);
        txtMess.setBorder(null);
        txtMess.setForeground(Color.RED);
        txtMess.setFont(new Font("Arial", Font.ITALIC, 13));
        pnlMess.add(txtMess);
        pnlNorth.add(pnlMess);
        add(pnlNorth, BorderLayout.NORTH);

        JPanel pnlCenter = new JPanel(new BorderLayout(5, 5));

        JPanel pnlBtn = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        btnThem = new JButton("Thêm");
        btnXoaRong = new JButton("Xóa rỗng");
        btnSua = new JButton("Sửa");
        btnXoa = new JButton("Xóa");
        btnLuu = new JButton("Lưu");
        btnLoc = new JButton("Lọc");

        cboMaSach = new JComboBox<>();
        cboMaSach.setPreferredSize(new Dimension(120, 25));

        pnlBtn.add(btnThem);
        pnlBtn.add(btnXoaRong);
        pnlBtn.add(btnSua);
        pnlBtn.add(btnXoa);
        pnlBtn.add(btnLuu);
        pnlBtn.add(btnLoc);
        pnlBtn.add(new JLabel("Tìm theo mã sách:"));
        pnlBtn.add(cboMaSach);

        table = new JTable();
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getTableHeader().setReorderingAllowed(false);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Danh sách các cuốn sách"));

        pnlCenter.add(pnlBtn, BorderLayout.NORTH);
        pnlCenter.add(scrollPane, BorderLayout.CENTER);
        add(pnlCenter, BorderLayout.CENTER);

        btnThem.addActionListener(this);
        btnXoaRong.addActionListener(this);
        btnSua.addActionListener(this);
        btnXoa.addActionListener(this);
        btnLuu.addActionListener(this);
        btnLoc.addActionListener(this);

        thuvien = new DanhSachSach();
        thuvien.napDuLieuTuFile();

        updateTableData();
        updateComboboxData();

        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int row = table.getSelectedRow();
                    fillForm(row);
                }
            }
        });
    }

    private Box taoDong(String lblLeft, JComponent compLeft, String lblRight, JComponent compRight) {
        Box box = Box.createHorizontalBox();
        box.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        JLabel l1 = new JLabel(lblLeft);
        if (l1.getText() == "International Standard Book Number (ISBN):") {
            l1.setPreferredSize(new Dimension(260, 25));
        } else {
            l1.setPreferredSize(new Dimension(140, 25));
        }
        box.add(l1);
        box.add(compLeft);

        if (lblRight != null && compRight != null) {
            box.add(Box.createHorizontalStrut(20));
            JLabel l2 = new JLabel(lblRight);
            l2.setPreferredSize(new Dimension(100, 25));
            box.add(l2);
            box.add(compRight);
        }
        return box;
    }

    private void fillForm(int row) {
        if (row != -1) {
            String maSach = (String) table.getValueAt(row, 0);
            Sach s = new Sach(maSach);
            ArrayList<Sach> dsSach = thuvien.getDsSach();
            if (thuvien.getDsSach().contains(s)) {
                s = dsSach.get(dsSach.indexOf(s));
                txtMaSach.setText(s.getMaSach());
                txtTuaSach.setText(s.getTuaSach());
                txtTacGia.setText(s.getTacGia());
                txtNhaXB.setText(s.getNhaXB());
                txtNamXB.setText(s.getNamXB() + "");
                txtSoTrang.setText(s.getSoTrang() + "");
                txtDonGia.setText(s.getDonGia() + "");
                txtISBN.setText(s.getIsbn());
                txtMaSach.setEditable(false);
            }
        }
    }

    private void updateComboboxData() {
        int n = thuvien.count();
        String[] items = new String[n];
        int i = 0;
        for (Sach s : thuvien.getDsSach()) {
            items[i] = s.getMaSach();
            i++;
        }
        cboMaSach.removeActionListener(this);
        cboMaSach.setModel(new DefaultComboBoxModel<String>(items));
        cboMaSach.addActionListener(this);
    }

    private void updateTableData() {
        tableModel = new SachTableModel(thuvien.getDsSach());
        table.setModel(tableModel);
    }

    private void clearTextfields() {
        txtMaSach.setText("");
        txtTuaSach.setText("");
        txtTacGia.setText("");
        txtNamXB.setText("");
        txtNhaXB.setText("");
        txtSoTrang.setText("");
        txtDonGia.setText("");
        txtISBN.setText("");
        txtMaSach.setEditable(true);
        txtMaSach.requestFocus();
        txtMess.setText("");
        table.clearSelection();
    }

    private Sach revertSachFromTextfields() {
        String maSach = txtMaSach.getText().trim();
        String tuaSach = txtTuaSach.getText().trim();
        String tacGia = txtTacGia.getText().trim();

        String nam = txtNamXB.getText().trim();
        int namXB = nam.length() == 0 ? 0 : Integer.parseInt(nam);

        String nhaXB = txtNhaXB.getText().trim();

        String trang = txtSoTrang.getText().trim();
        int soTrang = trang.length() == 0 ? 0 : Integer.parseInt(trang);

        String gia = txtDonGia.getText().trim();
        double donGia = gia.equals("") ? 0 : Double.parseDouble(gia);

        String isbn = txtISBN.getText().trim();
        return new Sach(maSach, tuaSach, tacGia, namXB, nhaXB, soTrang, donGia, isbn);
    }

    private void showMessage(String message, JTextField txt) {
        txt.requestFocus();
        txtMess.setText(message);
    }

    private boolean validData() {
        String ma = txtMaSach.getText().trim();
        String tua = txtTuaSach.getText().trim();
        String tacGia = txtTacGia.getText().trim();
        String nam = txtNamXB.getText().trim();
        String trang = txtSoTrang.getText().trim();
        String gia = txtDonGia.getText().trim();
        String isbn = txtISBN.getText().trim();

        // Mã sách bắt buộc, gồm 1 chữ cái in hoa và 3 chữ số, ví dụ A001.
        if (!(ma.length() > 0 && ma.matches("[A-Z]\\d{3}"))) {
            showMessage("Error: Mã sách theo mẫu: [A-Z]\\d{3}", txtMaSach);
            return false;
        }

        // Tựa sách và tác giả bắt buộc; chỉ nhận chữ cái, dấu cách và dấu nháy đơn.
        if (!(tua.length() > 0 && tua.matches("[a-zA-Z' ]+"))) {
            showMessage("Error: Tựa sách theo mẫu: [a-zA-Z' ]+", txtTuaSach);
            return false;
        }

        if (!(tacGia.length() > 0 && tacGia.matches("[a-zA-Z' ]+"))) {
            showMessage("Error: Tác giả theo mẫu: [a-zA-Z' ]+", txtTacGia);
            return false;
        }

        // Năm xuất bản không bắt buộc. Nếu nhập, năm phải từ 1900 đến trước năm hiện
        // tại.
        if (nam.length() > 0) {
            try {
                int namNhap = Integer.parseInt(nam);
                int namHienTai = Calendar.getInstance().get(Calendar.YEAR);
                if (!(namNhap >= 1900 && namNhap < namHienTai)) {
                    showMessage("Error: Năm xuất bản phải >= 1900 và < " + namHienTai, txtNamXB);
                    return false;
                }
            } catch (NumberFormatException ex) {
                showMessage("Error: Năm xuất bản phải nhập số.", txtNamXB);
                return false;
            }
        }

        // Số trang không bắt buộc. Nếu nhập, phải là số nguyên dương.
        if (trang.length() > 0) {
            try {
                int soTrang = Integer.parseInt(trang);
                if (soTrang <= 0) {
                    showMessage("Error: Số trang phải nhập số nguyên dương.", txtSoTrang);
                    return false;
                }
            } catch (NumberFormatException ex) {
                showMessage("Error: Số trang phải nhập số nguyên dương.", txtSoTrang);
                return false;
            }
        }

        // Đơn giá không bắt buộc. Nếu nhập, phải là số không âm.
        if (gia.length() > 0) {
            try {
                double donGia = Double.parseDouble(gia);
                if (donGia < 0) {
                    showMessage("Error: Đơn giá phải >= 0.", txtDonGia);
                    return false;
                }
            } catch (NumberFormatException ex) {
                showMessage("Error: Đơn giá phải nhập số.", txtDonGia);
                return false;
            }
        }

        // ISBN không bắt buộc; nếu nhập phải có dạng X-X-X-X hoặc X-X-X-X-X,
        // trong đó mỗi X là một nhóm chữ số.
        if (isbn.length() > 0 && !isbn.matches("\\d+(-\\d+){3,4}")) {
            showMessage("Error: ISBN có mẫu dạng X-X-X-X (hoặc X-X-X-X-X).", txtISBN);
            return false;
        }

        return true;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object o = e.getSource();

        if (o.equals(cboMaSach)) {
            String maSach = (String) cboMaSach.getSelectedItem();
            if (maSach != null) {
                Sach s = thuvien.timKiem(maSach);
                if (s != null) {
                    int index = thuvien.getDsSach().indexOf(s);
                    fillForm(index);
                    table.getSelectionModel().setSelectionInterval(index, index);
                    table.scrollRectToVisible(table.getCellRect(index, 0, true));
                }
            }
        } else if (o.equals(btnXoa)) {
            int row = table.getSelectedRow();
            if (row != -1) {
                int hoiNhac = JOptionPane.showConfirmDialog(this, "Chắc chắn xóa không?", "Chú ý",
                        JOptionPane.YES_NO_OPTION);
                if (hoiNhac == JOptionPane.YES_OPTION) {
                    if (thuvien.xoa1CuonSach(row)) {
                        txtMess.setText("Đã xóa 1 cuốn sách.");
                        updateTableData();
                        updateComboboxData();
                        clearTextfields();
                    }
                }
            } else {
                txtMess.setText("Bạn phải chọn cuốn sách cần xóa.");
            }
        } else if (o.equals(btnThem)) {
            if (validData()) {
                Sach s = revertSachFromTextfields();
                if (thuvien.themSach(s)) {
                    txtMess.setText("Thêm thành công 1 cuốn sách.");
                    updateTableData();
                    updateComboboxData();
                } else {
                    showMessage("Error: Trùng mã sách", txtMaSach);
                }
            }
        } else if (o.equals(btnXoaRong)) {
            clearTextfields();
        } else if (o.equals(btnSua)) {
            String maSachOld = txtMaSach.getText().trim();
            if (validData()) {
                Sach sachNew = revertSachFromTextfields();
                if (thuvien.capNhatSach(maSachOld, sachNew)) {
                    txtMess.setText("Cập nhật thành công.");
                    updateTableData();
                    int index = thuvien.getDsSach().indexOf(sachNew);
                    if (index != -1)
                        table.setRowSelectionInterval(index, index);
                } else {
                    txtMess.setText("Cần chọn cuốn sách để cập nhật.");
                }
            }
        } else if (o.equals(btnLuu)) {
            LuuTru.ghiXuongFile(thuvien.getDsSach());
            txtMess.setText("Lưu thành công.");
        } else if (o.equals(btnLoc)) {
            String regex = JOptionPane.showInputDialog("Nhập tựa sách cần lọc: ");
            if (regex != null && !regex.trim().equals("")) {
                ArrayList<Sach> temp = thuvien.filter(regex);
                table.setModel(new SachTableModel(temp));
            } else {
                updateTableData();
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                QuanLySachApp frm = new QuanLySachApp();
                frm.setVisible(true);
            }
        });
    }
}