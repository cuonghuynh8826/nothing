package lthsk_QLSach_stt08_HuynhThanhCuong_24639461;

import java.io.Serializable;
import java.util.Objects;

public class Sach implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String maSach;
    private String tuaSach;
    private String tacGia;
    private int namXB;
    private String nhaXB;
    private int soTrang;
    private double donGia;
    private String isbn;

    public Sach(String maSach) {
        this.maSach = maSach;
    }

    public Sach(String maSach, String tuaSach, String tacGia, int namXB, String nhaXB, int soTrang, double donGia,
            String isbn) {
        this.maSach = maSach;
        this.tuaSach = tuaSach;
        this.tacGia = tacGia;
        this.namXB = namXB;
        this.nhaXB = nhaXB;
        this.soTrang = soTrang;
        this.donGia = donGia;
        this.isbn = isbn;
    }

    public String getMaSach() {
        return maSach;
    }

    public void setMaSach(String maSach) {
        this.maSach = maSach;
    }

    public String getTuaSach() {
        return tuaSach;
    }

    public void setTuaSach(String tuaSach) {
        this.tuaSach = tuaSach;
    }

    public String getTacGia() {
        return tacGia;
    }

    public void setTacGia(String tacGia) {
        this.tacGia = tacGia;
    }

    public int getNamXB() {
        return namXB;
    }

    public void setNamXB(int namXB) {
        this.namXB = namXB;
    }

    public String getNhaXB() {
        return nhaXB;
    }

    public void setNhaXB(String nhaXB) {
        this.nhaXB = nhaXB;
    }

    public int getSoTrang() {
        return soTrang;
    }

    public void setSoTrang(int soTrang) {
        this.soTrang = soTrang;
    }

    public double getDonGia() {
        return donGia;
    }

    public void setDonGia(double donGia) {
        this.donGia = donGia;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        Sach sach = (Sach) o;
        return Objects.equals(maSach, sach.maSach);
    }

    @Override
    public int hashCode() {
        return Objects.hash(maSach);
    }

    @Override
    public String toString() {
        return maSach + ";" + tuaSach + ";" + tacGia + ";" + namXB + ";" + nhaXB + ";" + soTrang + ";" + donGia + ";"
                + isbn;
    }
}