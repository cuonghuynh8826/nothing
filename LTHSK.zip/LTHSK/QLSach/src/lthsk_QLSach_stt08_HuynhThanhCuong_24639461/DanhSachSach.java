package lthsk_QLSach_stt08_HuynhThanhCuong_24639461;

import java.util.ArrayList;

public class DanhSachSach {
    private ArrayList<Sach> dsSach;

    public DanhSachSach() {
        dsSach = new ArrayList<Sach>(10);
    }

    public void napDuLieuTuFile() {
        dsSach = LuuTru.docTuFile();
    }

    public ArrayList<Sach> getDsSach() {
        return dsSach;
    }

    public int count() {
        return dsSach.size();
    }

    public Sach timKiem(String maSach) {
        Sach s = new Sach(maSach);
        if (dsSach.contains(s)) {
            return dsSach.get(dsSach.indexOf(s));
        }
        return null;
    }

    public boolean xoa1CuonSach(int index) {
        if (index >= 0 && index < dsSach.size()) {
            dsSach.remove(index);
            return true;
        }
        return false;
    }

    public boolean themSach(Sach s) {
        if (dsSach.contains(s))
            return false;
        return dsSach.add(s);
    }

    /**
     * Cập nhật thông tin cuốn sách khi biết mã sách
     * Không được phép cập nhật trên trường khóa
     * 
     * @param maSachOld
     * @param sachNew
     */
    public boolean capNhatSach(String maSachOld, Sach sachNew) {
        Sach sachOld = new Sach(maSachOld);
        if (dsSach.contains(sachOld)) {
            sachOld = dsSach.get(dsSach.indexOf(sachOld));
            sachOld.setTuaSach(sachNew.getTuaSach());
            sachOld.setTacGia(sachNew.getTacGia());
            sachOld.setNamXB(sachNew.getNamXB());
            sachOld.setNhaXB(sachNew.getNhaXB());
            sachOld.setSoTrang(sachNew.getSoTrang());
            sachOld.setDonGia(sachNew.getDonGia());
            sachOld.setIsbn(sachNew.getIsbn());
            return true;
        }
        return false;
    }

    public ArrayList<Sach> filter(String regex) {
        ArrayList<Sach> temp = new ArrayList<>();
        for (Sach s : dsSach) {
            if (s.getTuaSach().toLowerCase().contains(regex.toLowerCase().trim())) {
                temp.add(s);
            }
        }
        return temp;
    }
}