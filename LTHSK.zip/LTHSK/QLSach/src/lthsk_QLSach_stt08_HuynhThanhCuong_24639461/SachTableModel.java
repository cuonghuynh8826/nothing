package lthsk_QLSach_stt08_HuynhThanhCuong_24639461;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;

public class SachTableModel extends AbstractTableModel {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private ArrayList<Sach> dsSach;
    private String[] columnNames = { "Mã sách", "Tựa sách", "Tác giả", "Năm xuất bản", "Nhà xuất bản", "Số trang",
            "Đơn giá", "ISBN" };

    public SachTableModel(ArrayList<Sach> dsSach) {
        this.dsSach = dsSach;
    }

    @Override
    public int getRowCount() {
        return dsSach.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Sach s = dsSach.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return s.getMaSach();
            case 1:
                return s.getTuaSach();
            case 2:
                return s.getTacGia();
            case 3:
                return s.getNamXB();
            case 4:
                return s.getNhaXB();
            case 5:
                return s.getSoTrang();
            case 6:
                return s.getDonGia();
            case 7:
                return s.getIsbn();
            default:
                return null;
        }
    }
}