package qlnhanvien;

import java.io.Serializable;
import java.util.ArrayList;

public class DSNhanVien implements Serializable {
    private static final long serialVersionUID = 1L;
    private ArrayList<NhanVien> listNV;

    public DSNhanVien(){
        listNV = new ArrayList<NhanVien>();
    }

    public NhanVien find(String code){
        int i = listNV.indexOf(new NhanVien(code));
        return i < 0 ? null : listNV.get(i);
    }

    public boolean add(NhanVien nv){
        if(listNV.contains(nv))
            return false;
        return listNV.add(nv);
    }

    public boolean del(String code){
        return listNV.remove(new NhanVien(code));
    }

    public ArrayList<NhanVien> getList(){
        return listNV;
    }
    public void setList(ArrayList<NhanVien>  listNV){
        this.listNV = listNV;
    }

    public int getSize(){
        return listNV.size();
    }

    public NhanVien getElement(int i){
        return i < 0 || i >= listNV.size() ? null : listNV.get(i);
    }

}
