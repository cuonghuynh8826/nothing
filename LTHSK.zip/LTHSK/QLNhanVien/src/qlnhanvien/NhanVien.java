package qlnhanvien;

import java.io.Serializable;

public class NhanVien implements Serializable{
    private static final long serialVersionUID = 1L;
    private final String code;
    private String fName, lName;
    private int age;
    private boolean sex;
    private double salary;

    public NhanVien(String code) {
        if (code == null || code.trim().isEmpty())
            throw new IllegalArgumentException("Ma khong hop le!");
        this.code = code;
    }

    public NhanVien(String code, String fName, String lName, int age, boolean sex, double salary) {
        if (code == null || code.trim().isEmpty())
            throw new IllegalArgumentException("Ma khong hop le!");
        this.code = code;
        setAge(age);
        setSalary(salary);
        setSex(sex);
        setfName(fName);
        setlName(lName);
    }

    public String getCode() {
        return code;
    }
    public String getfName() {
        return fName;
    }
    public void setfName(String fName) {
        if (fName == null || fName.trim().isEmpty())
            throw new IllegalArgumentException("Ho khong hop le!");
        this.fName = fName;
    }
    public String getlName() {
        return lName;
    }
    public void setlName(String lName) {
        if (lName == null || lName.trim().isEmpty())
            throw new IllegalArgumentException("Ten khong hop le!");
        this.lName = lName;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        if (age < 18 || age > 60)
            throw new IllegalArgumentException("Tuoi khong hop le!");
        this.age = age;
    }
    public boolean getSex() {
        return sex;
    }
    public void setSex(boolean sex) {
        this.sex = sex;
    }
    public double getSalary() {
        return salary;
    }
    public void setSalary(double salary) {
        if (!Double.isFinite(salary) || salary < 0)
            throw new IllegalArgumentException("Luong khong hop le!");
        this.salary = salary;
    }

    @Override
    public int hashCode() {
        return code.toLowerCase().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return obj instanceof NhanVien && code.equalsIgnoreCase(((NhanVien) obj).code);
    }
}
