package qlnhanvien;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Locale;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class QLNhanVienApp extends JFrame {
    private static final long serialVersionUID = 1L;
    private static final String FILE_PATH = "NhanVien.dat";
    private DSNhanVien listNV = new DSNhanVien();
    private DefaultTableModel model;
    private JTable table;
    private JTextField txtCode, txtFName, txtLName, txtAge, txtSalary, txtFindCode;
    private JComboBox<String> cbSex;

    public QLNhanVienApp() {
        setTitle("Quản Lý Nhân Viên");
        setSize(1000, 620);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(5, 5));
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int confirm = JOptionPane.showConfirmDialog(
                    QLNhanVienApp.this, "Bạn có muốn lưu các thay đổi trước khi thoát?",
                    "Xác nhận thoát", JOptionPane.YES_NO_CANCEL_OPTION
                );
                if (confirm == JOptionPane.YES_OPTION) {
                    save();
                    System.exit(0);
                } else if (confirm == JOptionPane.NO_OPTION) {
                    System.exit(0);
                }
            }
        });

        Box bNorth = Box.createVerticalBox();
        JLabel titleNorth = new JLabel("THÔNG TIN NHÂN VIÊN");
        titleNorth.setFont(new Font("Arial", Font.BOLD, 22));
        titleNorth.setForeground(Color.BLUE);
        titleNorth.setAlignmentX(Component.CENTER_ALIGNMENT);
        bNorth.add(titleNorth);

        Box pnlNorth = Box.createVerticalBox();
        pnlNorth.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createEtchedBorder(), "Nhập thông tin", TitledBorder.LEFT, TitledBorder.TOP,
            new Font("Arial", Font.BOLD, 15), Color.RED));

        txtCode = new JTextField();
        txtFName = new JTextField();
        txtLName = new JTextField();
        txtAge = new JTextField();
        txtSalary = new JTextField();
        cbSex = new JComboBox<>(new String[]{"Nam", "Nữ"});
        cbSex.setFont(new Font("Arial", Font.BOLD, 15));
        cbSex.setPreferredSize(new Dimension(80, 26));

        pnlNorth.add(createRow(new JLabel("Mã NV:"), txtCode));
        pnlNorth.add(createRow(new JLabel("Họ:"), txtFName, new JLabel("Tên:"), txtLName));
        pnlNorth.add(createRow(new JLabel("Tuổi:"), txtAge, new JLabel("Phái:"), cbSex));
        pnlNorth.add(createRow(new JLabel("Lương:"), txtSalary));
        bNorth.add(pnlNorth);
        add(bNorth, BorderLayout.NORTH);

        String[] tableColumns = {"Mã NV", "Họ", "Tên", "Tuổi", "Phái", "Lương"};
        model = new DefaultTableModel(tableColumns, 0) {
            private static final long serialVersionUID = 1L;

            @Override
            public boolean isCellEditable(int row, int col) {
                return col != 0; 
            }

            @Override
            public void setValueAt(Object value, int row, int col) {
                if (col == 0) return;
                String v = (value == null) ? "" : value.toString().trim();
                if (!checkValid(col, v, null)) return;

                NhanVien nv = listNV.find(getValueAt(row, 0).toString());
                if (nv != null) {
                    switch (col) {
                        case 1: nv.setfName(v); break;
                        case 2: nv.setlName(v); break;
                        case 3: nv.setAge(Integer.parseInt(v)); break;
                        case 4: nv.setSex("Nam".equalsIgnoreCase(v)); break;
                        case 5: nv.setSalary(Double.parseDouble(v)); break;
                    }
                }

                super.setValueAt(value, row, col);

                switch (col) {
                    case 1: txtFName.setText(v); break;
                    case 2: txtLName.setText(v); break;
                    case 3: txtAge.setText(v); break;
                    case 4: cbSex.setSelectedItem("Nam".equalsIgnoreCase(v) ? "Nam" : "Nữ"); break;
                    case 5: txtSalary.setText(v); break;
                }
            }
        };

        table = new JTable(model);
        table.setRowHeight(25);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getTableHeader().setReorderingAllowed(false);
        table.putClientProperty("terminateEditOnFocusLost", true);

        TableColumn colSex = table.getColumnModel().getColumn(4);
        colSex.setCellEditor(new DefaultCellEditor(new JComboBox<>(new String[]{"Nam", "Nữ"})));

        DefaultTableCellRenderer rightAlign = new DefaultTableCellRenderer();
        rightAlign.setHorizontalAlignment(SwingConstants.RIGHT);
        table.getColumnModel().getColumn(3).setCellRenderer(rightAlign);

        table.getColumnModel().getColumn(5).setCellRenderer(new DefaultTableCellRenderer() {
            private static final long serialVersionUID = 1L;
            @Override
            protected void setValue(Object value) {
                setHorizontalAlignment(SwingConstants.RIGHT);
                try {
                    double d = Double.parseDouble(value.toString());
                    setText(String.format(Locale.US, "%,.2f$", d));
                } catch (Exception e) {
                    setText(value != null ? value.toString() : "");
                }
            }
        });

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) displaySelectedRow();
        });
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel pLeft = new JPanel();
        pLeft.add(new JLabel("Tìm mã:"));
        txtFindCode = new JTextField(10);
        JButton btnFind = new JButton("Tìm");
        pLeft.add(txtFindCode);
        pLeft.add(btnFind);

        JPanel pRight = new JPanel();
        JButton btnAdd = new JButton("Thêm");
        JButton btnEdit = new JButton("Sửa");
        JButton btnBlank = new JButton("Xóa trắng");
        JButton btnDel = new JButton("Xóa");
        JButton btnSave = new JButton("Lưu");
        pRight.add(btnAdd);
        pRight.add(btnEdit);
        pRight.add(btnBlank);
        pRight.add(btnDel);
        pRight.add(btnSave);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, pLeft, pRight);
        splitPane.setResizeWeight(0.35);
        add(splitPane, BorderLayout.SOUTH);

        btnAdd.addActionListener(e -> addElement());
        btnEdit.addActionListener(e -> {
            if (editSelectedRow()) JOptionPane.showMessageDialog(this, "Cập nhật thành công!");
        });
        btnBlank.addActionListener(e -> makeBlank());
        btnDel.addActionListener(e -> del());
        btnFind.addActionListener(e -> find());
        btnSave.addActionListener(e -> save());
        txtFindCode.addActionListener(e -> find());

        for (JTextField tf : new JTextField[]{txtFName, txtLName, txtAge, txtSalary}) {
            tf.addActionListener(e -> editSelectedRow());
        }

        cbSex.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                String currentTableSex = String.valueOf(model.getValueAt(row, 4));
                String selectedSex = cbSex.getSelectedItem().toString();
                if (!selectedSex.equalsIgnoreCase(currentTableSex)) {
                    model.setValueAt(selectedSex, row, 4);
                }
            }
        });

        loadDataFromFile();
    }

    private Box createRow(JComponent... controls) {
        Box row = Box.createHorizontalBox();
        for (JComponent control : controls) {
            if (control instanceof JLabel) {
                control.setPreferredSize(new Dimension(66, 24));
                control.setFont(new Font("Arial", Font.BOLD, 15));
            }
            row.add(Box.createHorizontalStrut(10));
            row.add(control);
        }
        row.setBorder(BorderFactory.createEmptyBorder(3, 0, 3, 10));
        return row;
    }

    private boolean checkValid(int col, String val, Component comp) {
        String err = null;
        val = (val == null) ? "" : val.trim();

        switch (col) {
            case 0:
            case 1:
            case 2:
                if (val.isEmpty()) {
                    String[] labels = {"Mã nhân viên", "Họ", "Tên"};
                    err = labels[col] + " không được để trống!";
                }
                break;
            case 3:
                try {
                    int age = Integer.parseInt(val);
                    if (age < 18 || age > 60) err = "Tuổi phải từ 18 đến 60!";
                } catch (NumberFormatException e) {
                    err = "Tuổi phải là số nguyên!";
                }
                break;
            case 4:
                if (!val.equalsIgnoreCase("Nam") && !val.equalsIgnoreCase("Nữ")) {
                    err = "Phái phải là 'Nam' hoặc 'Nữ'!";
                }
                break;
            case 5:
                try {
                    Double salary_d = Double.parseDouble(val);
                    if (!Double.isFinite(salary_d) || salary_d < 0) err = "Lương phải là số dương hoặc bằng 0!";
                } catch (NumberFormatException e) {
                    err = "Tiền lương phải là số thực!";
                }
                break;
        }

        if (err != null) {
            JOptionPane.showMessageDialog(this, err, "Lỗi dữ liệu", JOptionPane.WARNING_MESSAGE);
            if (comp != null) {
                comp.requestFocus();
                if (comp instanceof JTextField) ((JTextField) comp).selectAll();
            }
            return false;
        }
        return true;
    }

    private boolean isTFValid() {
        return checkValid(0, txtCode.getText(), txtCode)
            && checkValid(1, txtFName.getText(), txtFName)
            && checkValid(2, txtLName.getText(), txtLName)
            && checkValid(3, txtAge.getText(), txtAge)
            && checkValid(5, txtSalary.getText(), txtSalary);
    }

    private void addRow(NhanVien nv) {
        model.addRow(new Object[]{
            nv.getCode(), nv.getfName(), nv.getlName(),
            nv.getAge(), nv.getSex() ? "Nam" : "Nữ", nv.getSalary()
        });
    }

    private boolean addElement() {
        if (!isTFValid()) return false;

        String code = txtCode.getText().trim();
        if (listNV.find(code) != null) {
            JOptionPane.showMessageDialog(this, "Mã nhân viên đã tồn tại!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            txtCode.selectAll();
            txtCode.requestFocus();
            return false;
        }

        NhanVien nv = new NhanVien(
            code,
            txtFName.getText().trim(),
            txtLName.getText().trim(),
            Integer.parseInt(txtAge.getText().trim()),
            "Nam".equalsIgnoreCase(cbSex.getSelectedItem().toString()),
            Double.parseDouble(txtSalary.getText().trim())
        );

        listNV.add(nv);
        addRow(nv);
        makeBlank();
        JOptionPane.showMessageDialog(this, "Thêm nhân viên thành công!");
        return true;
    }

    private boolean editSelectedRow() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Hãy chọn nhân viên trên bảng cần sửa!");
            return false;
        }
        if (!isTFValid()) return false;

        String code = model.getValueAt(row, 0).toString();
        NhanVien nv = listNV.find(code);
        if (nv == null) return false;

        String fName = txtFName.getText().trim();
        String lName = txtLName.getText().trim();
        int age = Integer.parseInt(txtAge.getText().trim());
        boolean sex = "Nam".equalsIgnoreCase(cbSex.getSelectedItem().toString());
        double salary = Double.parseDouble(txtSalary.getText().trim());

        nv.setfName(fName);
        nv.setlName(lName);
        nv.setAge(age);
        nv.setSex(sex);
        nv.setSalary(salary);

        model.setValueAt(fName, row, 1);
        model.setValueAt(lName, row, 2);
        model.setValueAt(String.valueOf(age), row, 3);
        model.setValueAt(sex ? "Nam" : "Nữ", row, 4);
        model.setValueAt(String.valueOf(salary), row, 5);

        return true;
    }

    private void displaySelectedRow() {
        int row = table.getSelectedRow();
        if (row < 0) return;

        txtCode.setText(model.getValueAt(row, 0).toString());
        txtCode.setEditable(false);
        txtFName.setText(model.getValueAt(row, 1).toString());
        txtLName.setText(model.getValueAt(row, 2).toString());
        txtAge.setText(model.getValueAt(row, 3).toString());
        cbSex.setSelectedItem(model.getValueAt(row, 4).toString());
        txtSalary.setText(model.getValueAt(row, 5).toString());
    }

    private void makeBlank() {
        table.clearSelection();
        txtCode.setText("");
        txtFName.setText("");
        txtLName.setText("");
        txtAge.setText("");
        txtSalary.setText("");
        cbSex.setSelectedIndex(0);
        txtCode.setEditable(true);
        txtCode.requestFocus();
    }

    private void del() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Hãy chọn nhân viên cần xóa!");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
            this, "Bạn có chắc chắn muốn xóa nhân viên này?", "Xác nhận", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            String code = model.getValueAt(row, 0).toString();
            listNV.del(code);
            model.removeRow(row);
            makeBlank();
            JOptionPane.showMessageDialog(this, "Đã xóa nhân viên thành công!");
        }
    }

    private void find() {
        String code = txtFindCode.getText().trim();
        if (code.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập mã cần tìm!");
            txtFindCode.requestFocus();
            return;
        }

        for (int i = 0; i < model.getRowCount(); i++) {
            if (model.getValueAt(i, 0).toString().equalsIgnoreCase(code)) {
                table.setRowSelectionInterval(i, i);
                table.scrollRectToVisible(table.getCellRect(i, 0, true));
                txtFindCode.selectAll();
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "Không tìm thấy nhân viên có mã: " + code);
    }
    
    private void save() {
        try {
            new LuuTru().saveFile(listNV, FILE_PATH);
            JOptionPane.showMessageDialog(this, "Đã lưu dữ liệu vào " + FILE_PATH + " thành công!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Lỗi khi lưu file: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadDataFromFile() {
        try {
            Object obj = new LuuTru().readFile(FILE_PATH);
            if (obj instanceof DSNhanVien) {
                listNV = (DSNhanVien) obj;
                model.setRowCount(0);
                for (int i = 0; i < listNV.getSize(); i++) {
                    addRow(listNV.getElement(i));
                }
            }
        } catch (Exception ex) {
            listNV = new DSNhanVien();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new QLNhanVienApp().setVisible(true));
    }
}