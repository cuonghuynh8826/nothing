package qlnhanvien;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class LuuTru {
    public boolean saveFile(Object obj, String filePath) throws Exception {
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath));;
        oos.writeObject(obj);
        oos.flush();
        oos.close();
        return true;
    }

    public Object readFile(String filePath) throws Exception {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filePath));
        Object o = ois.readObject();
        ois.close();
        return o;
    }
}